﻿namespace Northwind.Wpf.Infrastructure
{
    public interface IMainView : IView
    {

    }
}