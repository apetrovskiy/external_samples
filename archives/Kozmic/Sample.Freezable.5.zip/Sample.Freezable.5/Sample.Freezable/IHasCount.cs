namespace Sample.Freezable
{
    public interface IHasCount
    {
        int Count { get; }
    }
}