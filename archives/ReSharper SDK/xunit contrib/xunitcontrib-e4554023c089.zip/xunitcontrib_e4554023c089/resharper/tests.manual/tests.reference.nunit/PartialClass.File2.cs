﻿using NUnit.Framework;

namespace tests.reference.nunit
{
    [TestFixture]
    public partial class PartialClass
    {
        [Test]
        public void TestInFile2()
        {

        }
    }
}