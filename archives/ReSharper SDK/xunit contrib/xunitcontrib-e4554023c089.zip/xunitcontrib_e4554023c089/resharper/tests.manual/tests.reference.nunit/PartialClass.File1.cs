﻿using NUnit.Framework;

namespace tests.reference.nunit
{
    public partial class PartialClass
    {
        [Test]
        public void TestInFile1()
        {
        }
    }
}