using System.Reflection;
using System.Runtime.InteropServices;

[assembly : AssemblyCompany("http://xunitcontrib.codeplex.com")]
[assembly : AssemblyProduct("xunitcontrib.runner." + ProductInfo.AssemblyProduct)]
[assembly : AssemblyDescription("xUnit.net unit test provider for " + ProductInfo.Product)]
[assembly : AssemblyCopyright("Copyright (C) Matt Ellis")]
[assembly : ComVisible(false)]
[assembly : AssemblyVersion("1.3.0.*")]