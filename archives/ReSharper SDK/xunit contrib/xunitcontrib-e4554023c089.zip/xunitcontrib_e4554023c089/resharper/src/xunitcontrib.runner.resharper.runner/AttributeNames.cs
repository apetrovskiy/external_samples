namespace XunitContrib.Runner.ReSharper.RemoteRunner
{
    public static class AttributeNames
    {
        public const string AssemblyLocation = "AssemblyLocation";
        public const string TypeName = "TypeName";
        public const string MethodName = "MethodName";
        public const string TheoryName = "TheoryName";
        public const string Explicitly = "Explicitly";
        public const string Dynamic = "Dynamic";
    }
}