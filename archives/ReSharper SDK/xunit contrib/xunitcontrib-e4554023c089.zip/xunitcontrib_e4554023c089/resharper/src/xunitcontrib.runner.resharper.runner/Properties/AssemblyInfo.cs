﻿using System.Reflection;

[assembly: AssemblyTitle("xUnit.net remote unit test runner for " + ProductInfo.Product + " " + ProductInfo.Version)]
