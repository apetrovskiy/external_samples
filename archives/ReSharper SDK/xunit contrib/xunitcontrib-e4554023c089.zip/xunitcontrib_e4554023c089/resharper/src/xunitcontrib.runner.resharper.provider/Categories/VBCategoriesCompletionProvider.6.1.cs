﻿using JetBrains.ReSharper.Feature.Services.VB.CodeCompletion;

namespace XunitContrib.Runner.ReSharper.UnitTestProvider.Categories
{
    public partial class VBCategoriesCompletionProvider : XunitCategoriesCompletionProviderBase<IVBCodeCompletionContext>
    {
    }
}
