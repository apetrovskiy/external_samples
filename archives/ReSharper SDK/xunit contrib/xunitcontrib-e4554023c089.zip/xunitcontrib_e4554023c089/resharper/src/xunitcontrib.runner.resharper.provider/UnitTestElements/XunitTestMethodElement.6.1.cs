﻿using JetBrains.ReSharper.UnitTestFramework;

namespace XunitContrib.Runner.ReSharper.UnitTestProvider
{
    public partial class XunitTestMethodElement : IUnitTestElementContextSensitivePresentation
    {
    }
}