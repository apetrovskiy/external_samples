﻿public static class ProductInfo
{
    public const string Product = "ReSharper";
    public const string AssemblyProduct = "resharper";
    public const string Version = "7.1";
}
