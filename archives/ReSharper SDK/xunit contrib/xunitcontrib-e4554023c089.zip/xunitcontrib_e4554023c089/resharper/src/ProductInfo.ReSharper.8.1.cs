﻿public static class ProductInfo
{
    public const string Product = "ReSharper";
    public const string AssemblyProduct = "resharper";
    public const string Version = "8.1.23.546";
}
