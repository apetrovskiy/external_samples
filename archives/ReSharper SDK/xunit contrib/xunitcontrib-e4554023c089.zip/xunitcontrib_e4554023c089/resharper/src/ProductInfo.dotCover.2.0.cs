﻿public static class ProductInfo
{
    public const string Product = "dotCover";
    public const string AssemblyProduct = "dotcover";
    public const string Version = "2.0.406";
}