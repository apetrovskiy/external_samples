﻿internal static class ProductInfo
{
    public const string Product = "dotCover";
    public const string AssemblyProduct = "dotcover";
    public const string Version = "2.5.551.49";
}