#if WINDOWS_PHONE

// The compiler doesn't like missing namespaces, but only on the wp7 projects, oddly
namespace System.Runtime.Remoting.Messaging
{
}

#endif