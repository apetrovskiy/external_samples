﻿namespace System.Xml
{
    public class XmlElement : XmlNode
    {
        internal XmlElement(string name, XmlDocument ownerDocument) : base(name, ownerDocument)
        {
        }
    }
}