﻿using System.Reflection;

[assembly: AssemblyTitle("xunit-silverlight (ported by xunitcontrib)")]
[assembly: AssemblyDescription("Silverlight port of xunit.dll (from the xunitcontrib project)")]

