using System.Reflection;

[assembly: AssemblyFileVersion("0.2.0.0")]
