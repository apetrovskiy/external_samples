﻿using System.Reflection;

[assembly: AssemblyTitle("xunit.extensions-silverlight (ported by xunitcontrib)")]
[assembly: AssemblyDescription("Silverlight port of xunit.extensions.dll (from the xunitcontrib project)")]

