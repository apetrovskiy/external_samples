using System.Collections.Generic;

namespace System.Xml
{
    public class XmlNodeList : List<XmlNode>
    {
    }
}