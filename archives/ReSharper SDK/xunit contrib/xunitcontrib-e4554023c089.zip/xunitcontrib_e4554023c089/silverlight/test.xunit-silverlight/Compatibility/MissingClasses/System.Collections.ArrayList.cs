using System.Collections.Generic;

namespace Xunit
{
    internal class ArrayList : List<object>
    {
    }
}