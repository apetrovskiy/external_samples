﻿using Microsoft.Silverlight.Testing;

namespace XunitContrib.Runner.Silverlight.Toolkit
{
    [Exclusive]
    public class ExclusiveTestClassCommandTypeAdapter<TClassUnderTest> : TestClassCommandTypeAdapter<TClassUnderTest>
    {
    }
}