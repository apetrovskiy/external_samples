﻿using System.Reflection;

[assembly: AssemblyTitle("xunitcontrib.runner.silverlight.toolkit")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("xunitcontrib")]
[assembly: AssemblyProduct("xunitcontrib.runner.silverlight.toolkit")]
[assembly: AssemblyCopyright("Copyright © xunitcontrib 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.2.0.*")]