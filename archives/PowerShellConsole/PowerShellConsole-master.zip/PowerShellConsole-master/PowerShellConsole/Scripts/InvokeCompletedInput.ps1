﻿param($stuff)

$stuff | gm