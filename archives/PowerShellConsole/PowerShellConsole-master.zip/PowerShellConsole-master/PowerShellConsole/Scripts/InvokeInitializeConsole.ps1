﻿param($stuff)

$stuff
#$tse.Title = $stuff.ToString()
#$tse.Title = "[Ready] $(Get-Date)"
#$tse.TextEditor