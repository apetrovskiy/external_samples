﻿namespace TodoNancy
{
  public class Todo
  {
    public long id { get; set; }
    public string title { get; set; }
    public int order { get; set; }
    public bool completed { get; set; }
  }
}