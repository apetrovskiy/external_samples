
             #################################################
             ##    Web Authentication - made damn simple.   ##
             #################################################


   You've nuget installed this package so I don't to explain what this shiz does ;)

Starting Options
^^^^^^^^^^^^^^^^
   1. Use the web.config custom provider
                            or
   2. Manually wire up the providers you will offer.


Easy vs Hard
^^^^^^^^^^^^
   1. EASY: Choose to use the provided Nancy Module or Mvc Controller to make setup -really- simple.
            If you do this, you will need to install-package ..
      a. Nancy Module: Install-Package Nancy.Authentication.WorldDomination
      b. Mvc Controller: Install-Package WorldDomination.Web.Authentication.Mvc 
                            or
   2. HARD: Create your own module/controller, your own routes and code all of this. Manually.



Setup Instructions
^^^^^^^^^^^^^^^^^^

   1. NancyFX Manual Setup - https://github.com/PureKrome/WorldDomination.Web.Authentication/wiki/NancyFX-Manual-Setup
   2. NancyFX Automatic Setup - https://github.com/PureKrome/WorldDomination.Web.Authentication/wiki/NancyFX-Automatic-Setup
   3. MVC Manual Setup - https://github.com/PureKrome/WorldDomination.Web.Authentication/wiki/Mvc-Manual-Setup
   4. MVC Automatic Setup - https://github.com/PureKrome/WorldDomination.Web.Authentication/wiki/Mvc-Automatic-Setup


Bonus Pro Tips
^^^^^^^^^^^^^^
1. Free Login Images: Need some login buttons? Thought so: http://bit.ly/U3qSIL
3. Coding Choons: You can't get away without some pro coding choons. Here's 2
                  which will make your nipples hard :
                  a) http://soundcloud.com/phazing-004/dirty-south-phazing-radio-004
                  b) http://www.youtube.com/watch?v=cla38u6MrEI             

----------------------------------------------------------------------------------------


Now go forth and execute World Domination! Seriously. Go. Dominate. Even a wee bit. Go.


-Pure Krome [from Melbourne, Australia ... mate :) ]-
-Phillip Haydon [from Auckland, New Zealand... kia ora... BRO!]-