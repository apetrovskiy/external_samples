﻿namespace TodoNancy
{
  public class Todo
  {
    public int id { get; set; }
    public string title { get; set; }
    public int order { get; set; }
    public bool completed { get; set; }
  }
}