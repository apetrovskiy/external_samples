﻿This folder initially contains the files:
- EmailSinkElement.xsd
- PrefixEventTextFormatterElement.xsd
- SemanticLogging-svc.xml

After building the solution, it also contains:
- CustomSinkExtension.dll
- CustomTextFormatter.dll

You shoulld copy all of the files to the folder where you installed the
Semantic Logging Application Block out-of-process Windows Service that 
you can download from http://go.microsoft.com/fwlink/p/?LinkID=290903.