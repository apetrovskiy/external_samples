﻿MICROSOFT ENTERPRISE LIBRARY
Samples

Summary: This package contains code samples that support the Developer's Guide to Microsoft Enterprise Library.

The most up-to-date version of the documentation is available online:
http://go.microsoft.com/fwlink/p/?LinkID=290904


Microsoft patterns & practices
http://microsoft.com/practices
